from typing import List, Tuple, Dict
import asyncpg


class Channels:
    def __init__(self, connector: asyncpg.pool.Pool):
        self.connector = connector

    async def create_channels_table_if_not_exists(
            self
    ) -> None:

        await self.connector.execute("""
            CREATE TABLE IF NOT EXISTS channels (
            
                row_id SERIAL,

                user_ids BIGINT[],
                
                channel_name TEXT,                
                channel_link TEXT PRIMARY KEY,
                channel_id BIGINT,
                
                action TEXT
            );
        """)

    async def add_channel(
            self,
            user_id: int, link: str, name: str, channel_id: int
    ) -> None:

        await self.connector.execute("""
            INSERT INTO channels (
                user_ids, channel_link, channel_name, channel_id, action
            )
            VALUES ($1, $2, $3, $4, $5)
            ON CONFLICT (channel_link) DO UPDATE
                SET user_ids = channels.user_ids || EXCLUDED.user_ids,
                action = NULL;
        """, [user_id], link, name, channel_id, 'subscribe')

    async def del_channel(
            self,
            user_id: int, channel_link: str
    ) -> None:

        await self.connector.execute("""
            UPDATE channels
            SET user_ids = array_remove(user_ids, $1)
            WHERE channel_link = $2;
        """, user_id, channel_link)

        result = await self.connector.fetchrow("""
            SELECT user_ids
            FROM channels
            WHERE channel_link = $1;
        """, channel_link)

        if result and len(result['user_ids']) == 0:
            await self.connector.execute("""
                UPDATE channels
                SET action = 'remove'
                WHERE channel_link = $1;
            """, channel_link)

    async def get_channels(
            self,
            user_id: int
    ) -> List[str]:

        results = await self.connector.fetch("""
            SELECT DISTINCT channel_link, channel_name
            FROM channels
            WHERE $1 = ANY(user_ids);
        """, user_id)

        return [
            f'{row["channel_link"]} - {row["channel_name"]}'
            if row["channel_name"] else {row["channel_link"]}
            for row in results
        ]

    async def get_channels_del(
            self
    ) -> List[Dict]:

        return await self.connector.fetch("""
            SELECT channel_link, channel_name
            FROM channels;
        """)

    async def get_join_channels(
            self
    ) -> List[Tuple]:

        result = await self.connector.fetch("""
            SELECT channel_id, channel_name, channel_link
            FROM channels
            WHERE action = 'subscribe';
        """)
        return [(row["channel_id"], row["channel_name"], row["channel_link"]) for row in result]

    async def subscribed(
            self,
            link: str, name: str, channel_id: int
    ) -> None:

        await self.connector.execute("""
            UPDATE channels
            SET action = NULL
            WHERE (channel_link = $1 AND channel_name = $2)
                OR (channel_name = $2 AND channel_id = $3);
        """, link, name, channel_id)

    async def get_leave_channels(
            self
    ) -> List[Tuple]:

        result = await self.connector.fetch("""
            SELECT channel_id, channel_link
            FROM channels
            WHERE action = 'remove';
        """)
        return [(row["channel_id"], row["channel_link"]) for row in result]

    async def delete_channel(
            self,
            channel_id: int
    ) -> None:

        await self.connector.execute("""
            DELETE FROM channels
            WHERE channel_id = $1;
        """, channel_id)
