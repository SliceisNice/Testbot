from typing import List, Dict

import asyncpg


class Posts:
    def __init__(self, connector: asyncpg.pool.Pool):
        self.connector = connector

    async def create_posts_table_if_not_exists(
            self
    ) -> None:

        await self.connector.execute("""
            CREATE TABLE IF NOT EXISTS posts (
            
                row_id SERIAL,

                user_id BIGINT,
                message TEXT,
                
                status BOOL DEFAULT FALSE                
            );
        """)

    async def add_post(
            self,
            user_id: int, message: str
    ) -> None:

        await self.connector.execute("""
            INSERT INTO posts (user_id, message)
            VALUES ($1, $2);
        """, user_id, message)

    async def get_posts(
            self
    ) -> List[Dict]:

        return await self.connector.fetch("""
            SELECT * 
            FROM posts
            WHERE status = FALSE;
        """)

    async def change_status(
            self,
            row_id: int
    ) -> None:

        await self.connector.execute("""
            UPDATE posts
            SET status = TRUE
            WHERE row_id = $1;
        """, row_id)
