import logging
from typing import Dict

from aiogram import Router, Bot, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, Chat

from core.database.db_channels import Channels
from core.utils.messages import message_answer
from core.utils.userbot import get_channel_name

router = Router()


@router.message(Command(commands='glist'))
async def cmd_chats(
        message: Message,
        channels: Channels,
        menu: Dict,
        state: FSMContext
) -> None:

    await state.clear()

    user_id = message.from_user.id

    channel_list = await channels.get_channels(user_id)

    if channel_list:
        text = '\n'.join(channel_list)
    else:
        text = menu["empty"]

    await message_answer(
        message,
        menu["cmd_chats"].format(channels_list=text)
    )


@router.message(F.text.startswith('/chanel '))
async def channel_add(
        message: Message, bot: Bot,
        channels: Channels,
        menu: Dict
) -> None:

    link = message.text[8:]

    user_id = message.from_user.id

    chat_id, chat_name = 0, None
    channel_search = link \
        .replace('@', '') \
        .replace('https://t.me/joinchat/', '') \
        .replace('https://t.me/', '') \
        .replace('t.me/', '')

    try:
        chat: Chat = await bot.get_chat(f"@{channel_search}")
        chat_name = chat.title
        chat_id = chat.id
    except Exception as e:
        logging.info(e)
        if channel_search.startswith('+'):
            channel_search = channel_search[1:]
        try:
            result = await get_channel_name(channel_search)
            try:
                chat_name = result.title
                chat_id = result.id
            except Exception as e:
                logging.info(e)
                chat_name = result.chat.title
                chat_id = result.chat.id

        except Exception as e:
            logging.info(e)

    if chat_id != 0:
        chat_id = int(str(chat_id)[4:]) if str(chat_id).startswith('-100') else chat_id

    await channels.add_channel(user_id, link, chat_name, chat_id)

    await message_answer(
        message,
        menu["added"]
    )


#del
@router.message(F.text.startswith('/gdel '))
async def channel_del(
        message: Message,
        channels: Channels,
        menu: Dict
) -> None:

    link = message.text[6:]

    user_id = message.from_user.id

    await channels.del_channel(user_id, link)

    await channels.get_channels_del()

    await message_answer(
        message,
        menu["deleted"]
    )
