import json
from typing import Dict

from aiogram import Router, F, Bot
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery

from core.keyboards.inline import ikb_back
from core.utils.chat_cleaner import msg_list, del_msg
from core.utils.states import UserState

router = Router()


@router.callback_query(F.data == 'u_keywords')
async def keywords_menu(callback: CallbackQuery,
                        menu: Dict, state: FSMContext) -> None:
    await state.clear()

    with open('keys/keywords.json', 'r') as file:
        word_list = json.load(file)

    keywords = "; ".join(word_list)

    msg = await callback.message.edit_text(
        text=menu["keywords"].format(keywords),
        reply_markup=ikb_back(menu["buttons"])
    )
    msg_list.append(msg.message_id)
    await state.set_state(UserState.keyword)


@router.message(F.text, UserState.keyword)
async def get_keywords(message: Message, bot: Bot,
                       menu: Dict) -> None:
    keywords = message.text.lower()
    new_keywords = sorted(keywords.split("; "))

    with open('keys/keywords.json', 'w') as file:
        json.dump(new_keywords, file, indent=2)

    msg = await message.answer(
        text=menu["keywords"].format(keywords),
        reply_markup=ikb_back(menu["buttons"])
    )
    await del_msg(bot, message, msg_list)
    msg_list.append(msg.message_id)


@router.callback_query(F.data == 'u_word_add')
async def keywords_add(callback: CallbackQuery,
                       menu: Dict, state: FSMContext) -> None:
    await state.clear()

    with open('keys/keywords.json', 'r') as file:
        word_list = json.load(file)

    keywords = "; ".join(word_list)

    msg = await callback.message.edit_text(
        text=menu["word_add"].format(keywords),
        reply_markup=ikb_back(menu["buttons"])
    )
    msg_list.append(msg.message_id)
    await state.set_state(UserState.keyword_add)


@router.message(F.text, UserState.keyword_add)
async def get_keyword(message: Message, bot: Bot,
                      menu: Dict) -> None:
    keywords = message.text.lower()
    new_keywords = keywords.split("; ")

    with open('keys/keywords.json', 'r') as file:
        existing_keywords = json.load(file)

    existing_keywords.extend(new_keywords)
    existing_keywords = sorted(list(set(existing_keywords)))

    with open('keys/keywords.json', 'w') as file:
        json.dump(existing_keywords, file, indent=2)

    msg = await message.answer(
        text=menu["word_added"].format(keywords),
        reply_markup=ikb_back(menu["buttons"])
    )
    await del_msg(bot, message, msg_list)
    msg_list.append(msg.message_id)


@router.callback_query(F.data == 'u_word_del')
async def keywords_add(callback: CallbackQuery,
                       menu: Dict, state: FSMContext) -> None:
    await state.clear()

    with open('keys/keywords.json', 'r') as file:
        word_list = json.load(file)

    keywords = "; ".join(word_list)

    msg = await callback.message.edit_text(
        text=menu["word_del"].format(keywords),
        reply_markup=ikb_back(menu["buttons"])
    )
    msg_list.append(msg.message_id)
    await state.set_state(UserState.keyword_del)


@router.message(F.text, UserState.keyword_del)
async def get_keyword(message: Message, bot: Bot,
                         menu: Dict) -> None:
    keywords = message.text.lower()
    keywords_to_remove = keywords.split("; ")

    with open('keys/keywords.json', 'r') as file:
        existing_keywords = json.load(file)

    existing_keywords = sorted(keyword for keyword in existing_keywords if keyword not in keywords_to_remove)

    with open('keys/keywords.json', 'w') as file:
        json.dump(existing_keywords, file, indent=2)

    msg = await message.answer(
        text=menu["word_deleted"].format(keywords),
        reply_markup=ikb_back(menu["buttons"])
    )
    await del_msg(bot, message, msg_list)
    msg_list.append(msg.message_id)
