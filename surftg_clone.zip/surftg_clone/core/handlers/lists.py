import json
from typing import Dict

from aiogram import Router, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

from core.utils.messages import message_answer

router = Router()


@router.message(Command(commands='list'))
async def cmd_list(
        message: Message,
        menu: Dict,
        state: FSMContext
) -> None:

    await state.clear()

    user_id = message.from_user.id

    with open(f'keywords/{user_id}.json', 'r') as file:
        keywords = json.load(file)

    if keywords:
        text = '; '.join(keywords)
    else:
        text = menu["empty"]

    await message_answer(
        message,
        menu["cmd_list"].format(keywords_list=text)
    )


@router.message(F.text.startswith('/add '))
async def channel_add(
        message: Message,
        menu: Dict
) -> None:

    keyword = message.text[5:]

    user_id = message.from_user.id

    with open(f'keywords/{user_id}.json', 'r') as file:
        existing_keywords = json.load(file)

    if keyword and keyword not in existing_keywords:
        existing_keywords.append(keyword)
        existing_keywords = sorted(existing_keywords)

        with open(f'keywords/{user_id}.json', 'w') as file:
            json.dump(existing_keywords, file, indent=2)

    await message_answer(
        message,
        menu["add_keywords"]
    )


#del
@router.message(F.text.startswith('/del '))
async def channel_del(
        message: Message,
        menu: Dict
) -> None:

    keyword_remove = message.text[5:]

    user_id = message.from_user.id

    with open(f'keywords/{user_id}.json', 'r') as file:
        existing_keywords = json.load(file)

    if keyword_remove in existing_keywords:
        existing_keywords = [keyword for keyword in existing_keywords if keyword != keyword_remove]
        existing_keywords = sorted(existing_keywords)

        with open(f'keywords/{user_id}.json', 'w') as file:
            json.dump(existing_keywords, file, indent=2)

    await message_answer(
        message,
        menu["del_keywords"]
    )
