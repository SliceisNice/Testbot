from aiogram import Router

from core.handlers.start import router as start
from core.handlers.lists import router as lists
from core.handlers.chats import router as chats
from core.handlers.keywords import router as keywords


router = Router()
router.include_routers(
    start,
    lists,
    chats,
    keywords
)
