import json
import os
from typing import Dict

from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message

from core.utils.messages import message_answer

router = Router()


@router.message(Command(commands='start'))
async def cmd_start(
        message: Message,
        menu: Dict
) -> None:

    user_id = message.from_user.id

    await message_answer(
        message,
        menu["cmd_start"]
    )

    if not os.path.exists(f'keywords/{user_id}.json'):
        with open(f'keywords/{user_id}.json', 'w') as file:
            json.dump([], file)

    with open('keys/stop_list.json', 'r') as file:
        users = json.load(file)

    users = sorted(user for user in users if user != user_id)

    with open('keys/stop_list.json', 'w') as file:
        json.dump(users, file, indent=2)


@router.message(Command(commands='stop'))
async def cmd_stop(
        message: Message,
        menu: Dict
) -> None:

    user_id = message.from_user.id

    await message_answer(
        message,
        menu["cmd_stop"]
    )

    with open('keys/stop_list.json', 'r') as file:
        users = json.load(file)

    users.append(user_id)
    users = sorted(list(set(users)))

    with open('keys/stop_list.json', 'w') as file:
        json.dump(users, file, indent=2)
