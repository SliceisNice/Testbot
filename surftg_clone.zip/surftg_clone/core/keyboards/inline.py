from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder


def ikb_admin(menu: dict) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()

    builder.button(text=menu["list"], callback_data='u_channels')
    builder.button(text=menu["add"], callback_data='u_channel_add')
    builder.button(text=menu["del"], callback_data='u_channel_del')
    builder.button(text=menu["words"], callback_data='u_keywords')
    builder.button(text=menu["add"], callback_data='u_word_add')
    builder.button(text=menu["del"], callback_data='u_word_del')
    builder.button(text=menu["black_list"], callback_data='u_black_list')
    builder.button(text=menu["add"], callback_data='u_black_list_add')
    builder.button(text=menu["del"], callback_data='u_black_list_del')

    builder.adjust(1, 2, 1, 2, 1, 2)
    return builder.as_markup()


def ikb_back(menu: dict) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()

    builder.button(text=menu["back"], callback_data='u_start')

    builder.adjust(1)
    return builder.as_markup()


def ikb_del_channel(menu: dict, channels: list) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()

    for channel in channels:
        builder.button(text=f'{channel["channel_name"]}',
                       callback_data=f'u_c_del±{channel["channel_link"]}')

    builder.button(text=menu["back"], callback_data='u_start')

    builder.adjust(* [1] * len(channels), 1)
    return builder.as_markup()
