from typing import Callable, Union, Dict, Any, Awaitable

from aiogram import BaseMiddleware
from aiogram.types import Message, CallbackQuery

from core.settings import settings

admin_ids = [int(admin_id) for admin_id in settings.admins.admin_ids]


class MenuMiddleware(BaseMiddleware):

    async def __call__(
            self,
            handler: Callable[[Union[Message, CallbackQuery], Dict[str, Any]], Awaitable[Any]],
            event: Union[Message, CallbackQuery],
            data: Dict[str, Any]
    ) -> Any:

        if event.from_user.id in admin_ids:
            return await handler(event, data)
