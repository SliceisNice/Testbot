from environs import Env
from dataclasses import dataclass


@dataclass
class Bots:
    bot_token: str


@dataclass
class Admins:
    admin_ids: list


@dataclass
class Userbot:
    api_id: int
    api_hash: str
    phone: str


@dataclass
class Db:
    db_user: str
    db_password: str
    db_database: str
    db_host: str
    db_port: int


@dataclass
class Logs:
    error_log: str
    info_log: str


@dataclass
class Settings:
    bots: Bots
    admins: Admins
    userbot: Userbot
    db: Db
    logs: Logs


def get_settings(path: str):
    env = Env()
    env.read_env(path)

    return Settings(
        bots=Bots(
            bot_token=env.str('BOT_TOKEN')
        ),
        admins=Admins(
            admin_ids=env.list('ADMIN_IDS')
        ),
        userbot=Userbot(
            api_id=env.int('API_ID'),
            api_hash=env.str('API_HASH'),
            phone=env.str('PHONE')
        ),
        db=Db(
            db_user=env.str('DB_USER'),
            db_password=env.str('DB_PASSWORD'),
            db_database=env.str('DB_DATABASE'),
            db_host=env.str('DB_HOST'),
            db_port=env.int('DB_PORT')
        ),
        logs=Logs(
            error_log=env.str('ERROR_LOG_FILENAME'),
            info_log=env.str('INFO_LOG_FILENAME')
        )
    )


settings = get_settings('input')
