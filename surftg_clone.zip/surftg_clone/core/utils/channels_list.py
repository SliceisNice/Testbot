import asyncio
from random import randint

from core.database.db_channels import Channels
from core.utils.userbot import channel_join, channel_left


async def chat_join_left(channels: Channels):
    while True:
        await asyncio.sleep(30)

        join_channels = await channels.get_join_channels()
        if join_channels:
            for channel_id, channel_name, channel_link in join_channels:
                await channel_join(channel_link)
                await channels.subscribed(channel_name, channel_link, channel_id)

                await asyncio.sleep(randint(30, 60))

        leave_channels = await channels.get_leave_channels()
        if leave_channels:
            for channel_id, channel_link in leave_channels:
                await channel_left(channel_id, channel_link)

                await channels.delete_channel(channel_id)
                await asyncio.sleep(randint(30, 60))
