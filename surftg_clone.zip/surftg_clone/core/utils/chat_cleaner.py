from datetime import datetime

from aiogram import Bot, Router
from aiogram.types import Message


router = Router()
msg_list = list()


async def del_msg(bot: Bot, message: Message, message_list: list) -> None:
    for message_id in message_list:
        try:
            await bot.delete_message(
                chat_id=message.from_user.id,
                message_id=message_id)
        except Exception as e:
            print(f'{datetime.now()} - {message.from_user.id} - {e}')

    await message.delete()
    msg_list.clear()


async def del_bot_msg(user_id: int, bot: Bot, message_list: list) -> None:
    for message_id in message_list:
        try:
            await bot.delete_message(
                chat_id=user_id,
                message_id=message_id)
        except Exception as e:
            print(f'{datetime.now()} - {user_id} - {e}')

    msg_list.clear()


@router.message()
async def del_text(message: Message) -> None:
    await message.delete()
