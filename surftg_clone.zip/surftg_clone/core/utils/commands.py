from aiogram import Bot
from aiogram.types import BotCommand, BotCommandScopeDefault


async def set_commands(bot: Bot):
    commands = [
        BotCommand(
            command='start',
            description='Запуск бота'
        ),
        BotCommand(
            command='stop',
            description='Зупинка бота'
        ),
        BotCommand(
            command='glist',
            description='Перелік груп'
        ),
        BotCommand(
            command='list',
            description='Перелік запитів'
        )
    ]

    await bot.set_my_commands(commands, BotCommandScopeDefault())
