import asyncpg

from core.settings import settings


async def create_pool() -> asyncpg.Pool:
    return await asyncpg.create_pool(
        user=settings.db.db_user, password=settings.db.db_password,
        host=settings.db.db_host, port=settings.db.db_port,
        database=settings.db.db_database, command_timeout=60,
        min_size=10, max_size=1000
    )
