from core.settings import settings
from core.utils.create_pool import create_pool


async def check_or_create_database() -> None:

    pool = await create_pool()

    async with pool.acquire() as connection:
        result = await connection.fetchval(f"""
            SELECT COUNT(*) 
            FROM pg_catalog.pg_database 
            WHERE datname = '{settings.db.db_database}'
        """)

    if result != 1:
        async with pool.acquire() as connection:
            await connection.execute(f"""
                CREATE DATABASE {settings.db.db_database} 
                WITH OWNER = {settings.db.db_user} 
                ENCODING = 'UTF8' 
                CONNECTION LIMIT = -1
            """)
