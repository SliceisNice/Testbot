from typing import List

from core.utils.create_pool import create_pool


async def get_user_ids(
        channel_id: int
) -> List[int]:

    pool = await create_pool()

    async with pool.acquire() as connection:
        async with connection.transaction():
            result = await connection.fetch("""
                SELECT user_ids
                FROM channels
                WHERE channel_id = $1;
        """, channel_id)

    await pool.close()

    user_ids = []
    for record in result:
        user_ids.extend(record['user_ids'])

    return user_ids


async def add_post(
        user_id: int, message: str
) -> None:

    pool = await create_pool()

    async with pool.acquire() as connection:
        async with connection.transaction():
            await connection.execute("""
                INSERT INTO posts (user_id, message)
                VALUES ($1, $2);
            """, user_id, message)


async def add_row(channel_id: int, channel_name: str, text: str, creative: str) -> None:
    pool = await create_pool()

    async with pool.acquire() as connection:
        async with connection.transaction():
            await connection.execute("""
            INSERT INTO posts (
                channel_id, channel_name, text, creative, date_time
            )
            VALUES ($1, $2, $3, $4, NOW());
            """, channel_id, channel_name, text, creative)

    await pool.close()


async def subscribed(link) -> None:
    pool = await create_pool()

    async with pool.acquire() as connection:
        async with connection.transaction():
            await connection.execute("""
                UPDATE channels
                SET action = NULL
                WHERE channel_link = $1;
            """, link)

    await pool.close()


async def add_channel_id(channel_name: str, channel_id: int) -> None:
    pool = await create_pool()

    async with pool.acquire() as connection:
        async with connection.transaction():
            await connection.execute("""
            UPDATE channels
            SET action = NULL, channel_id = $2
            WHERE channel_name = $1;
        """, channel_name, channel_id)

    await pool.close()


async def update_channel_id(
        channel_name: str, channel_id: int
) -> None:

    pool = await create_pool()

    async with pool.acquire() as connection:
        async with connection.transaction():
            await connection.execute("""
                UPDATE channels
                SET action = NULL, channel_id = $2
                WHERE channel_name = $1;
            """, channel_name, channel_id)

    await pool.close()
