import json
import logging

from aiogram import Dispatcher


async def get_texts(
        dp: Dispatcher
) -> None:

    with open("texts/texts.json", 'r') as file:
        menu_str = file.read()

    try:
        menu = json.loads(menu_str)
    except json.JSONDecodeError as e:
        logging.critical(e)
        menu = {}

    dp['lang'] = 'UA'
    dp['menu'] = menu
