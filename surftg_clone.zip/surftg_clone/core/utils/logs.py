from core.settings import settings

LOGGING_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "default": {
            "format": "%(asctime)s - [%(levelname)s]: %(filename)s (Line: %(lineno)d) - %(message)s",
            "datefmt": "%Y-%m-%d %H:%M:%S",
            "encoding": "utf-8"
        },
        "simple": {
            "format": "%(message)s",
            "encoding": "utf-8"
        },
        "console": {
            "format": "%(asctime)s - [%(levelname)s]: %(filename)s (Line: %(lineno)d) - %(message)s",
            "datefmt": "%Y-%m-%d %H:%M:%S",
            "encoding": "utf-8"
        },
    },

    "handlers": {
        "log_file": {
            "formatter": "default",
            "level": "ERROR",
            "class": "logging.handlers.RotatingFileHandler",
            "filename": settings.logs.error_log,
            "backupCount": 2,
        },
        "info_file": {
            "formatter": "default",
            "level": "INFO",
            "class": "logging.handlers.RotatingFileHandler",
            "filename": settings.logs.info_log,
            "backupCount": 2,
        },
        "verbose_output": {
            "formatter": "simple",
            "level": "DEBUG",
            "class": "logging.StreamHandler",
            "stream": "ext://sys.stdout",
        },
        "console": {
            "formatter": "console",
            "class": "logging.StreamHandler",
            "stream": "ext://sys.stdout",
        },
    },
    "loggers": {
        "tryceratops": {
            "level": "DEBUG",
            "handlers": [
                "verbose_output",
            ],
        },
    },
    "root": {
        "level": "INFO",
        "handlers": [
            "log_file",
            "info_file",
            "console"
        ]
    }
}

# logging.config.dictConfig(LOGGING_CONFIG)
