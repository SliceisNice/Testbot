import asyncio
import logging

from aiogram import Bot
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InputMediaPhoto, FSInputFile


async def message_answer(
        message: Message,
        text: str,
        kb: InlineKeyboardMarkup = None
) -> int:
    try:
        msg = await message.answer(
            text=text,
            reply_markup=kb
        )

        return msg.message_id
    except Exception as e:
        logging.debug(e)


async def message_error(
        message: Message,
        bot: Bot,
        text: str,
        kb: InlineKeyboardMarkup = None,
        timer: int = 5
) -> None:

    try:
        msg = await message.answer(
            text=text,
            reply_markup=kb
        )
        await asyncio.sleep(timer)
        await bot.delete_message(chat_id=message.from_user.id, message_id=msg.message_id)

        await message.delete()

    except Exception as e:
        logging.debug(e)


async def callback_error(
        callback: CallbackQuery,
        bot: Bot,
        text: str,
        kb: InlineKeyboardMarkup = None,
        timer: int = 5
) -> None:

    try:
        msg = await callback.message.answer(
            text=text,
            reply_markup=kb
        )
        await asyncio.sleep(timer)
        await bot.delete_message(chat_id=callback.from_user.id, message_id=msg.message_id)

    except Exception as e:
        logging.debug(e)


async def callback_edit(
        callback: CallbackQuery,
        text: str,
        kb: InlineKeyboardMarkup
) -> int:
    await callback.answer()

    try:
        msg = await callback.message.edit_text(
            text=text,
            reply_markup=kb
        )

        return msg.message_id
    except Exception as e:
        logging.debug(e)


async def callback_answer(
        callback: CallbackQuery,
        text: str,
        kb: InlineKeyboardMarkup
) -> None:
    await callback.answer()

    try:
        await callback.message.answer(
            text=text,
            reply_markup=kb
        )
        await callback.answer()

    except Exception as e:
        logging.debug(e)


async def callback_answer_del(
        callback: CallbackQuery,
        text: str,
        kb: InlineKeyboardMarkup
) -> None:
    await callback.answer()

    try:
        await callback.message.answer(
            text=text,
            reply_markup=kb
        )
        await callback.message.delete()

    except Exception as e:
        logging.debug(e)


async def edit_caption_or_text(
        callback: CallbackQuery,
        text: str,
        kb: InlineKeyboardMarkup
) -> int:
    await callback.answer()

    try:
        msg = await callback.message.edit_caption(
            caption=text,
            reply_markup=kb
        )

    except Exception as e:
        logging.debug(e)

        try:
            msg = await callback.message.edit_text(
                text=text,
                reply_markup=kb
            )

        except Exception as e:
            logging.debug(e)

            msg = await callback.message.edit_reply_markup(
                reply_markup=kb
            )

    return msg.message_id


async def edit_or_answer_del(
        callback: CallbackQuery,
        text: str,
        kb: InlineKeyboardMarkup
) -> int:
    await callback.answer()

    try:
        msg = await callback.message.edit_text(
            text=text,
            reply_markup=kb
        )

    except Exception as e:
        logging.debug(e)

        msg = await callback.message.answer(
            text=text,
            reply_markup=kb
        )
        await callback.message.delete()

    return msg.message_id


async def edit_photo_and_caption(
        callback: CallbackQuery,
        photo: str,
        text: str,
        kb: InlineKeyboardMarkup
) -> None:
    await callback.answer()

    try:
        await callback.message.edit_media(
            media=InputMediaPhoto(type='photo', media=FSInputFile(photo))
        )

    except Exception as e:
        logging.debug(e)

    try:
        await callback.message.edit_caption(
            caption=text,
            reply_markup=kb
        )

    except Exception as e:
        logging.debug(e)
