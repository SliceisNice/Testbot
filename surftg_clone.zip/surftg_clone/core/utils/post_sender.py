import asyncio
import json
import logging
from typing import Dict

from aiogram import Bot

from core.database.db_posts import Posts


async def start_posting(
        bot: Bot,
        posts: Posts
) -> None:

    while True:
        data = await posts.get_posts()

        if data:
            for row in data:
                asyncio.create_task(bot_send_msg(bot, row))

                await posts.change_status(row["row_id"])

        else:
            await asyncio.sleep(10)


async def bot_send_msg(
        bot: Bot, row: Dict
) -> None:

    with open('keys/stop_list.json', 'r') as file:
        user_ids = json.load(file)

    if row["user_id"] in user_ids:
        return

    try:
        await bot.send_message(
            chat_id=row["user_id"],
            text=row["message"]
        )

    except Exception as e:
        logging.info(e)
