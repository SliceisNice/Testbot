from aiogram.fsm.state import State, StatesGroup


class AdminState(StatesGroup):

    check_password = State()
    new_password = State()


class UserState(StatesGroup):

    link = State()

    keyword = State()
    keyword_add = State()
    keyword_del = State()

    black_list = State()
    black_list_add = State()
    black_list_del = State()
