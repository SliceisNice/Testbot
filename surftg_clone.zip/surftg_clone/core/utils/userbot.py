import json
import re
from datetime import datetime

from telethon.sync import TelegramClient, events
from telethon.tl.functions.channels import LeaveChannelRequest, JoinChannelRequest
from telethon.tl.functions.messages import ImportChatInviteRequest, CheckChatInviteRequest

from core.settings import settings
from core.utils.db_user_bot import subscribed, add_channel_id, get_user_ids, add_post

api_id = settings.userbot.api_id
api_hash = settings.userbot.api_hash
phone = settings.userbot.phone


client = TelegramClient(phone, api_id, api_hash)


@client.on(events.NewMessage(incoming=True))
async def handle_new_message(
        event
) -> None:

    if event.message and event.message.peer_id.channel_id:

        user_ids = await get_user_ids(event.message.peer_id.channel_id)
        for user_id in user_ids:
            text = event.message.text.lower()

            with open(f'keywords/{user_id}.json', 'r') as file:
                word_list = json.load(file)

            keyword_pattern = r'\b(?:' + '|'.join(re.escape(word.lower()) for word in word_list) + r')\b'

            target_words = re.findall(keyword_pattern, text)

            # for keyword in target_words:
            #     if keyword.lower() in text:
            #         text = text.replace(keyword, f'<u>{keyword}</u>')

            if target_words:
                channel_id = event.message.peer_id.channel_id
                message_id = event.message.id
                sender = await event.get_sender()
                author = sender.username
                creative = f'https://t.me/c/{channel_id}/{message_id}'

                message = f"""@{author}:\n{event.message.text}\n\n{creative}"""
                await add_post(user_id, message)


async def channel_join(channel_link) -> None:
    channel_link = channel_link
    channel = channel_link \
        .replace('@', '') \
        .replace('https://t.me/joinchat/', '') \
        .replace('https://t.me/', '') \
        .replace('t.me/', '')

    try:
        await client(JoinChannelRequest(channel))
        await subscribed(channel_link)

    except Exception as e:
        print(e)
        if channel.startswith('+'):
            channel = channel[1:]

        try:
            result = await client(ImportChatInviteRequest(channel))
            await subscribed(channel_link)
            if result and result.chats[0]:
                channel_id = result.chats[0].id
                channel_name = result.chats[0].title
                await add_channel_id(channel_name, channel_id)

        except Exception as e:
            with open('logs/userbot.log', 'a') as log_file:
                log_file.write(f'{datetime.now()} - Channel: {channel_link} - {e}' + '\n')


async def channel_left(channel_id, channel_link) -> None:
    try:
        await client(LeaveChannelRequest(channel_id))
    except Exception as e:
        print(e)

        channel_link = channel_link \
            .replace('@', '') \
            .replace('https://t.me/joinchat/', '') \
            .replace('https://t.me/', '') \
            .replace('t.me/', '')
        if channel_link.startswith('+'):
            channel_link = channel_link[1:]
        try:
            await client(LeaveChannelRequest(channel_link))
        except Exception as e:
            with open('logs/userbot.log', 'a') as log_file:
                log_file.write(f'{datetime.now()} - Channel: {channel_id} : {channel_link} - {e}' + '\n')


async def get_channel_name(channel):
    return await client(CheckChatInviteRequest(hash=channel))


async def user_bot():
    with open('logs/userbot.log', 'a') as log_file:
        log_file.write(f'STARTED {datetime.now()}\n')

    await client.start()
    await client.run_until_disconnected()

    with open('logs/userbot.log', 'a') as log_file:
        log_file.write(f'ENDED {datetime.now()}\n')
