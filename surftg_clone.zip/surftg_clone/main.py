import asyncio
import contextlib
import logging.config

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.redis import RedisStorage

from core.database.db_channels import Channels
from core.database.db_posts import Posts
from core.middlewares.schema_middleware import MenuMiddleware

from core.settings import settings
from core.utils.channels_list import chat_join_left

from core.utils.commands import set_commands
from core.utils.create_pool import create_pool

from core.handlers.routers import router
from core.utils.db_create import check_or_create_database
from core.utils.get_text import get_texts
from core.utils.logs import LOGGING_CONFIG
from core.utils.post_sender import start_posting
from core.utils.userbot import user_bot


async def start_bot(bot: Bot, channels: Channels, posts: Posts) -> None:
    await set_commands(bot)
    await channels.create_channels_table_if_not_exists()
    await posts.create_posts_table_if_not_exists()

    asyncio.create_task(user_bot())
    asyncio.create_task(chat_join_left(channels))

    asyncio.create_task(start_posting(bot, posts))


async def stop_bot() -> None:
    pass


async def start():
    logging.config.dictConfig(LOGGING_CONFIG)

    await check_or_create_database()

    bot = Bot(
        token=settings.bots.bot_token,
        default=DefaultBotProperties(
            parse_mode=ParseMode.HTML,
            link_preview_is_disabled=True
        )
    )

    pool_connect = await create_pool()
    storage = RedisStorage.from_url('redis://localhost:6379/0')
    dp = Dispatcher(storage=storage)

    await get_texts(dp)

    # middlewares
    dp.message.middleware(MenuMiddleware())
    dp.callback_query.middleware(MenuMiddleware())

    dp.startup.register(start_bot)
    dp.shutdown.register(stop_bot)

    # routers
    dp.include_routers(router)

    # database
    db_channels = Channels(pool_connect)
    db_posts = Posts(pool_connect)

    try:
        await bot.delete_webhook(drop_pending_updates=True)
        await dp.start_polling(
            bot,
            allowed_updates=dp.resolve_used_update_types(),
            channels=db_channels,
            posts=db_posts
        )
    except Exception as e:
        logging.error(e)
    finally:
        await bot.session.close()
        await pool_connect.close()


if __name__ == '__main__':
    with contextlib.suppress(KeyboardInterrupt, SystemExit):
        asyncio.run(start())
